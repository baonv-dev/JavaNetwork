package OOP;

public class Main {
	public static void main(String[] args)
	{
		Dog dog = new Dog();
		dog.capNhapThongTin();
		dog.hienThiThongTin();
		dog.printInformation();
	}
} 
