package OOP;

public class Bird {

}
