package OOP;

public interface Iinformation {
	public void printInformation();
}

